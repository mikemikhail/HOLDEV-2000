**NOTICE**: This PyPI entry has been deprecated in favor of the ``tensorboard``
name found at https://pypi.python.org/pypi/tensorboard for TensorBoard 1.6.0+.
Only bugfix updates on 1.5.x will be applied to this old package name.

To upgrade past the version shown on this page, please ensure that you *first*
``pip uninstall tensorflow-tensorboard`` and then ``pip install tensorboard``.

------------

TensorBoard is a suite of web applications for inspecting and understanding
your TensorFlow runs and graphs.


