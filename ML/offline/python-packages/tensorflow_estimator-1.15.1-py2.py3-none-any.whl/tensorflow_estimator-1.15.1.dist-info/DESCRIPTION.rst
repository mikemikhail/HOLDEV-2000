TensorFlow Estimator is a high-level API that encapsulates model training,
evaluation, prediction, and exporting.


